import Image from "next/image"
import { Badge } from "@/components/ui/badge"

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
type ProjectStatus = "draft" | "in_progress" | "done" | "archived"


export default function ProjectPreview({
    title,
    excerpt,
    status,
    techStack,
    coverImageUrl,
}: {
    title: string
    excerpt: string
    status: ProjectStatus
    techStack: string
    coverImageUrl?: string | null
}) {
    const chips = techStack
        ? techStack.split(",").map((t) => t.trim()).filter(Boolean)
        : []

    return (
        <Card className="h-fit bg-card border border-dashed border-border/60">
            <CardHeader>
                <CardTitle className="text-sm font-semibold">
                    Live preview
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-xs">
                <div className="aspect-[16/9] w-full overflow-hidden rounded-md bg-muted flex items-center justify-center">
                    {coverImageUrl ? (
                        <Image
                            src={coverImageUrl}
                            alt={title || "Project cover"}
                            width={400}
                            height={225}
                            className="h-full w-full object-cover"
                        />
                    ) : (
                        <span className="text-[11px] text-muted-foreground">
                            Cover image preview
                        </span>
                    )}
                </div>

                <div className="flex items-start justify-between gap-2">
                    <div>
                        <p className="text-sm font-medium">
                            {title || "Project title"}
                        </p>
                        <p className="text-[11px] text-muted-foreground line-clamp-2">
                            {excerpt ||
                                "Short summary of your project will appear here in cards and lists."}
                        </p>
                    </div>
                    <Badge variant="outline" className="text-[10px]">
                        {status === "draft"
                            ? "Draft"
                            : status === "in_progress"
                                ? "In progress"
                                : status === "done"
                                    ? "Completed"
                                    : "Archived"}
                    </Badge>
                </div>

                {chips.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                        {chips.map((t) => (
                            <Badge
                                key={t}
                                variant="outline"
                                className="text-[10px] px-1.5 py-0"
                            >
                                {t}
                            </Badge>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    )
}
